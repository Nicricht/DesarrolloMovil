package com.example.miregistro.ui.theme

import androidx.compose.ui.graphics.Color

//colores de marca para nuestro diseño
val Primario = Color(0xFF583FD9)
val PrimarioOscuro = Color(0xFF3A22A8)
val PrimarioClaro = Color(0xFFC9BEFF)
val Secundario = Color(0xFF00A6A6)
val Acento = Color(0xFFFF6B4A)
val AcentoOscuro = Color(0xFFE0482A)
//Colores neutros
val Blanco = Color(0xFFFFFFFF)
val FondoClaro = Color(0xFFF6F5FB)
val SuperficieClaro = Color(0xFFFFFF)
val TextoOscuro = Color(0xFF1C1B22)
val TextoClaro = Color(0xFFF6F5FB)
val FondoOscuro = Color(0xFF14131A)
val SuperficieOscuro = Color(0xFF1F1027)
val GrisDeshabilitado = Color(0xFFBDBAC7)
//colores para los mensajes al usuario
val Exito = Color(0xFF2E9E5B)
val ExitoFondo = Color(0xFF3F5EA)
package com.example.miregistro.ui.components

import androidx.annotation.DrawableRes
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.miregistro.R
import com.example.miregistro.ui.theme.Dimens
import com.example.miregistro.ui.theme.MiregistroTheme

@Composable
fun AvatarCircular(
    @DrawableRes imagen: Int,
    descripcion: String,
    modifier: Modifier = Modifier
){
    Image(
        painter = painterResource(id = imagen),
        contentDescription = descripcion,
        contentScale = ContentScale.Crop,
        modifier = modifier.size(Dimens.tamanoAvatar)
            .shadow(6.dp, CircleShape)
            .clip(CircleShape)
            .border(Dimens.bordeAvatar, MaterialTheme.colorScheme.surface, CircleShape)
    )
}
//previsualizaciones opcionales
@Preview(showBackground = true)
@Composable
private fun AvatarCircularPreview(){
    MiregistroTheme {
        AvatarCircular(
            imagen = R.drawable.avatar_usuario,
            descripcion = "",
            modifier = Modifier.padding(16.dp)
        )
    }
}
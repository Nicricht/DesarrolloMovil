package cl.duocuc.segurosbpo.ui.theme

import androidx.compose.ui.graphics.Color


val Primario = Color(0xFF5B3FD9)

val PrimarioOscuro = Color(0xFF3A22A8)

val PrimarioClaro = Color(0xFF00A6A6)

val Secundario = Color(255, 255, 255,255)

val Acento = Color(0xFFFF6B4A)

val AcentoOscuro = Color(0xFFE0482A)


val Blanco = Color(0xFFFFFFFF)
val FondoClaro = Color(0xFFF6F5FB)
val SuperficieClara = Color(0xFFFFFFFF)
val TextoOscuro = Color(0xFF1C1B22)
val TextoClaro = Color(0xFFFFFFFF)
val FondoOscuro = Color(0xFF14131A)
val SuperficieOscura = Color(0xFF1F1D27)
val GrisDeshabilitado = Color(0xFFBDBAC7)


val Exito = Color(0xFF17633A)
val ExitoFondo = Color(0xFFEAF7EF)
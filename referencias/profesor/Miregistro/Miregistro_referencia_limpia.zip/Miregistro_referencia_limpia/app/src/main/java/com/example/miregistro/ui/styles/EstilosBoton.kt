package com.example.miregistro.ui.styles

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ButtonColors
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ButtonElevation
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.miregistro.ui.theme.Blanco
import com.example.miregistro.ui.theme.Dimens
import com.example.miregistro.ui.theme.GrisDeshabilitado
import com.example.miregistro.ui.theme.Primario

object EstilosBoton{
    val forma = RoundedCornerShape(Dimens.radioBoton) //border raidus
    val relleno = PaddingValues(20.dp,12.dp) //padding
    //Botones principales: Relleno morado. texto blanco
    @Composable
    fun calorPrincipal(): ButtonColors = ButtonDefaults.buttonColors(
        containerColor = Primario,
        contentColor = Blanco,
        disabledContainerColor = GrisDeshabilitado,
        disabledContentColor = Blanco
        )

    @Composable
    fun coloresSecundarios(): ButtonColors = ButtonDefaults.outlinedButtonColors(
        containerColor = MaterialTheme.colorScheme.primary
    )

    //Bordes botones secundarios
    @Composable
    fun bordesSecundarios(): BorderStroke = BorderStroke(
        Dimens.bordeBoton, MaterialTheme.colorScheme.primary
    )

    //Sombra del boton principal
    @Composable
    fun elevacion(): ButtonElevation = ButtonDefaults.buttonElevation(
        defaultElevation = Dimens.elevacionBoton,
        pressedElevation = 1.dp
    )
}

//clase css
fun Modifier.estiloAltoBoton(): Modifier = this.height(Dimens.alturaBoton)